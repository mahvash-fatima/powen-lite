<?php

function powen_load_customizer_controls_scripts() {
	wp_enqueue_script(
			'powen-customizer-control-scripts', // Give the script a unique ID
			get_template_directory_uri(). '/pro/js/customizer-control.js', array( 'jquery' ), // Define dependencies
			POWEN_VERSION, // Define a version (optional)
			true // Specify whether to put in footer (leave this true)
	);
	wp_localize_script( 'powen-customizer-control-scripts', 'powen_pro_images', get_template_directory_uri() . '/pro/img' );

}

add_action( 'customize_controls_enqueue_scripts', 'powen_load_customizer_controls_scripts');

function powen_no_sanitization( $input ){
	return $input;
}

function powen_copy_lite_customizer_settings(){
	$powen_pro_theme_mod = get_theme_mod( 'powen-pro' );

	if( empty( $powen_pro_theme_mod ) ){
		$powen_lite_theme_mod = get_option( "theme_mods_powen-lite" );
		update_option( "theme_mods_powen-pro" , $powen_lite_theme_mod );
	}

}
add_action( 'after_switch_theme', 'powen_copy_lite_customizer_settings' );
