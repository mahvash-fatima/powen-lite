<?php

/**
 * Creates new options in customizer for the pro version
 */

function powen_customizer_pro_options( WP_Customize_Manager $wp_customize )
{

	$default_body_font = '';

	//Pro Menu
	$wp_customize->add_setting( 'powen_mod[pro_mobile_nav_title_textbox]', array(
	    'sanitize_callback' => 'sanitize_text_field',
	    'capability'        => 'edit_theme_options',
	) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'powen_mod[pro_mobile_nav_title_textbox]', array(
	    'label'    => __( 'Pro Menu Title', 'powen-lite' ),
	    'description' => __( 'This text is shown only on a small screen.', 'powen-lite' ),
	    'section'  => 'menu_locations',
	    'settings' => 'powen_mod[pro_mobile_nav_title_textbox]',
	) ) );

	$wp_customize->add_setting( 'powen_mod[hide_pro_mobile_nav]', array(
	    'capability'        => 'edit_theme_options',
	    'sanitize_callback' => 'sanitize_text_field',
	) );

	$wp_customize->add_control( new WP_Customize_Control ( $wp_customize, 'powen_mod[hide_pro_mobile_nav]', array(
	    'type'    => 'checkbox',
	    'label'   => __('Hide', 'powen-lite'),
	    'section' => 'menu_locations',
	) ) );

	$wp_customize->add_setting( 'powen_mod[hide_footer_nav]', array(
	    'capability'        => 'edit_theme_options',
	    'sanitize_callback' => 'sanitize_text_field',
	) );

	$wp_customize->add_control( new WP_Customize_Control ( $wp_customize, 'powen_mod[hide_footer_nav]', array(
	    'type'    => 'checkbox',
	    'label'   => __('Switch Off Footer Menu', 'powen-lite'),
	    'section' => 'menu_locations',
	) ) );

	//Font Icon
	$wp_customize->add_panel( 'powen_font_icon_panel', array(
		'capability' => 'edit_theme_options',
		'title'      => __( 'Font Icon', 'powen-lite' ),
	) );

	for ( $i = 0; $i <= apply_filters( 'powen_increase_font_icon', 1 ); $i++ ) {

		$wp_customize->add_section( 'powen_font_icon_' . $i, array(
			'title'       => sprintf( __( 'Font Icon %s', 'powen-lite' ), $i + 1 ),
			'description' => __( 'Set up your font icon link', 'powen-lite' ),
			'capability'  => 'edit_theme_options',
			'panel'       => 'powen_font_icon_panel',
		) );

		$wp_customize->add_setting( 'powen_font['.$i.'][icon]', array(
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'powen_sanitize_choices',
		) );

		$wp_customize->add_control( 'powen_font['.$i.'][icon]', array(
			'label'    => __( 'Icon', 'powen-lite' ),
			'settings' => 'powen_font['.$i.'][icon]',
			'section'  => 'powen_font_icon_' . $i,
			'type'     => 'select',
			'choices'  => powen_font_icon_array(),
		) );

		$wp_customize->add_setting( 'powen_font['.$i.'][url]', array(
			'sanitize_callback' => 'esc_url_raw',
			'capability'        => 'edit_theme_options',
		) );

		$wp_customize->add_control( 'powen_font['.$i.'][url]', array(
			'label'    => __( 'URL', 'powen-lite' ),
			'settings' => 'powen_font['.$i.'][url]',
			'section'  => 'powen_font_icon_' . $i,
			'type'     => 'text',
		) );
	}

	//Load More Button

	$wp_customize->add_section( 'powen_load_more_section' , array(
	    'title'      =>  __( 'Load More', 'powen-lite' ),
	    'capability' => 'edit_theme_options',
	    'panel'      => 'powen_content_pannel',
	) );

	$wp_customize->add_setting( 'powen_mod[load_more]', array(
	    'capability'        => 'edit_theme_options',
	    'sanitize_callback' => 'sanitize_text_field',
	) );

	$wp_customize->add_control( new WP_Customize_Control ( $wp_customize, 'powen_mod[load_more]', array(
	    'label'   => __('Hide Load More Button', 'powen-lite'),
	    'type'    => 'checkbox',
	    'section' => 'powen_load_more_section',
	) ) );

	//Pagination

	$wp_customize->add_section( 'powen_pagination_section' , array(
	    'title'      =>  __( 'Pagination', 'powen-lite' ),
	    'capability' => 'edit_theme_options',
	    'panel'      => 'powen_content_pannel',
	) );

	$wp_customize->add_setting( 'powen_mod[pagination]', array(
	    'capability'        => 'edit_theme_options',
	    'sanitize_callback' => 'sanitize_text_field',
	) );

	$wp_customize->add_control( new WP_Customize_Control ( $wp_customize, 'powen_mod[pagination]', array(
	    'label'   => __('Hide Pagination', 'powen-lite'),
	    'type'    => 'checkbox',
	    'section' => 'powen_pagination_section',
	) ) );

	//Infinite Ajax Scrolling

	$wp_customize->add_section( 'powen_infinite_scrolling_section' , array(
	    'title'      =>  __( 'Infinite Ajax Scrolling', 'powen-lite' ),
	    'capability' => 'edit_theme_options',
	    'panel'      => 'powen_content_pannel',
	) );

	$wp_customize->add_setting( 'powen_mod[stop_infinite_ajax_scrolling]', array(
	    'capability'        => 'edit_theme_options',
	    'sanitize_callback' => 'sanitize_text_field',
	) );

	$wp_customize->add_control( new WP_Customize_Control ( $wp_customize, 'powen_mod[stop_infinite_ajax_scrolling]', array(
	    'label'   => __('Stop Infinite Ajax Scrolling', 'powen-lite'),
	    'type'    => 'checkbox',
	    'section' => 'powen_infinite_scrolling_section',
	) ) );

	//Flexible Layout

	$wp_customize->add_section( 'powen_flexible_layout_section' , array(
	    'title'      =>  __( 'Flexible Layout', 'powen-lite' ),
	    'capability' => 'edit_theme_options',
	    'panel'      => 'powen_content_pannel',
	) );

	$wp_customize->add_setting( 'powen_mod[flexible_layout]', array(
		'default'           => '1150',
	    'capability'        => 'edit_theme_options',
	    'sanitize_callback' => 'sanitize_text_field',
	) );

	$wp_customize->add_control( new WP_Customize_Control ( $wp_customize, 'powen_mod[flexible_layout]', array(
		'type'        => 'text',
		'section'     => 'powen_flexible_layout_section',
		'label'       => __( 'Value', 'powen-lite' ),
		'description' => __( 'Write only <strong>numbers</strong> and not <strong>px</strong>. It should not be less than <strong>900</strong>', 'powen-lite' ),
	) ) );

	//Add Spots
	$wp_customize->add_panel( 'powen_add_spots_pannel', array(
	    'capability'     => 'edit_theme_options',
	    'title'          => __( 'Ad Spots', 'powen-lite' ),
	) );

	//Header Top Most
	$wp_customize->add_section( 'powen_header_primary_section' , array(
	    'title'      =>  __( 'Header Top Most', 'powen-lite' ),
	    'capability' => 'edit_theme_options',
	    'panel'      => 'powen_add_spots_pannel',
	) );

	$wp_customize->add_setting( 'powen_mod[header_primary]', array(
	    'sanitize_callback' => 'powen_no_sanitization',
	    'capability'        => 'edit_theme_options',
	) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'powen_mod[header_primary]', array(
		'label'    =>   __( 'Short Code', 'powen-lite' ),
		'type'     => 'textarea',
		'section'  =>  'powen_header_primary_section',
		'settings' =>  'powen_mod[header_primary]',
	) ) );
	//Before Site Identity
	$wp_customize->add_section( 'powen_before_site_branding_section' , array(
	    'title'      =>  __( 'Before Site Identity', 'powen-lite' ),
	    'capability' => 'edit_theme_options',
	    'panel'      => 'powen_add_spots_pannel',
	) );

	$wp_customize->add_setting( 'powen_mod[before_site_branding]', array(
	    'sanitize_callback' => 'powen_no_sanitization',
	    'capability'        => 'edit_theme_options',
	) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'powen_mod[before_site_branding]', array(
		'label'    =>   __( 'Short Code', 'powen-lite' ),
		'type'     => 'textarea',
		'section'  =>  'powen_before_site_branding_section',
		'settings' =>  'powen_mod[before_site_branding]',
	) ) );

	//After Site Identity
	$wp_customize->add_section( 'powen_after_site_branding_section' , array(
		'title'      =>  __( 'After Site Identity', 'powen-lite' ),
		'capability' => 'edit_theme_options',
		'panel'      => 'powen_add_spots_pannel',
	) );

	$wp_customize->add_setting( 'powen_mod[after_site_branding]', array(
		'sanitize_callback' => 'powen_no_sanitization',
		'capability'        => 'edit_theme_options',
	) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'powen_mod[after_site_branding]', array(
		'label'    =>   __( 'Short Code', 'powen-lite' ),
		'type'     => 'textarea',
		'section'  =>  'powen_after_site_branding_section',
		'settings' =>  'powen_mod[after_site_branding]',
	) ) );

	//After First Home Post
	$wp_customize->add_section( 'powen_after_first_home_post_section' , array(
		'title'      =>  __( 'After First Home Post', 'powen-lite' ),
		'capability' => 'edit_theme_options',
		'panel'      => 'powen_add_spots_pannel',
	) );

	$wp_customize->add_setting( 'powen_mod[after_first_home_post]', array(
		'sanitize_callback' => 'powen_no_sanitization',
		'capability'        => 'edit_theme_options',
	) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'powen_mod[after_first_home_post]', array(
		'label'    =>   __( 'Short Code', 'powen-lite' ),
		'type'     => 'textarea',
		'section'  =>  'powen_after_first_home_post_section',
		'settings' =>  'powen_mod[after_first_home_post]',
	) ) );

	//Before Content
	$wp_customize->add_section( 'powen_before_content_section' , array(
	    'title'      =>  __( 'Before Content', 'powen-lite' ),
	    'capability' => 'edit_theme_options',
	    'panel'      => 'powen_add_spots_pannel',
	) );

	$wp_customize->add_setting( 'powen_mod[before_content]', array(
	    'sanitize_callback' => 'powen_no_sanitization',
	    'capability'        => 'edit_theme_options',
	) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'powen_mod[before_content]', array(
		'label'    =>   __( 'Short Code', 'powen-lite' ),
		'type'     => 'textarea',
		'section'  =>  'powen_before_content_section',
		'settings' =>  'powen_mod[before_content]',
	) ) );

	//Above Footer
	$wp_customize->add_section( 'powen_above_footer_section' , array(
		'title'      =>  __( 'Above Footer', 'powen-lite' ),
		'capability' => 'edit_theme_options',
		'panel'      => 'powen_add_spots_pannel',
	) );

	$wp_customize->add_setting( 'powen_mod[above_footer]', array(
		'sanitize_callback' => 'powen_no_sanitization',
		'capability'        => 'edit_theme_options',
	) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'powen_mod[above_footer]', array(
		'label'    =>   __( 'Short Code', 'powen-lite' ),
		'type'     => 'textarea',
		'section'  =>  'powen_above_footer_section',
		'settings' =>  'powen_mod[above_footer]',
	) ) );

	//Footer Widgets
	$wp_customize->add_section( 'powen_footer_widgets_section' , array(
		'title'      =>  __( 'Footer Widgets', 'powen-lite' ),
		'capability' => 'edit_theme_options',
		'panel'      => 'powen_add_spots_pannel',
	) );

	$wp_customize->add_setting( 'powen_mod[footer_widgets]', array(
		'sanitize_callback' => 'powen_no_sanitization',
		'capability'        => 'edit_theme_options',
	) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'powen_mod[footer_widgets]', array(
		'label'    =>   __( 'Short Code', 'powen-lite' ),
		'type'     => 'textarea',
		'section'  =>  'powen_footer_widgets_section',
		'settings' =>  'powen_mod[footer_widgets]',
	) ) );

	//Footer Site Info Begins
	$wp_customize->add_section( 'powen_footer_site_info_begins_section' , array(
		'title'      =>  __( 'Footer Site Info Begins', 'powen-lite' ),
		'capability' => 'edit_theme_options',
		'panel'      => 'powen_add_spots_pannel',
	) );

	$wp_customize->add_setting( 'powen_mod[footer_site_info_begins]', array(
		'sanitize_callback' => 'powen_no_sanitization',
		'capability'        => 'edit_theme_options',
	) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'powen_mod[footer_site_info_begins]', array(
		'label'    =>   __( 'Short Code', 'powen-lite' ),
		'type'     => 'textarea',
		'section'  =>  'powen_footer_site_info_begins_section',
		'settings' =>  'powen_mod[footer_site_info_begins]',
	) ) );

	//Footer Site Info Ends
	$wp_customize->add_section( 'powen_footer_site_info_ends_section' , array(
		'title'      =>  __( 'Footer Site Info Ends', 'powen-lite' ),
		'capability' => 'edit_theme_options',
		'panel'      => 'powen_add_spots_pannel',
	) );

	$wp_customize->add_setting( 'powen_mod[footer_site_info_ends]', array(
		'sanitize_callback' => 'powen_no_sanitization',
		'capability'        => 'edit_theme_options',
	) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'powen_mod[footer_site_info_ends]', array(
		'label'    =>   __( 'Short Code', 'powen-lite' ),
		'type'     => 'textarea',
		'section'  =>  'powen_footer_site_info_ends_section',
		'settings' =>  'powen_mod[footer_site_info_ends]',
	) ) );

	//Powen Pro Fonts

	$wp_customize->add_section( 'powen_fonts_section' , array(
	  'title'      =>  __( 'Font Family', 'powen-lite' ),
	  'capability' => 'edit_theme_options',
	  'panel'      => 'powen_typography_pannel',
	) );

	$wp_customize->add_setting( 'powen_mod[pro_fonts]', array(
		'sanitize_callback' => 'powen_sanitize_choices',
		'capability'        => 'edit_theme_options',
		'default'			=> 'Open Sans',
	));

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'powen_mod[pro_fonts]', array(
		'label'    =>   __( 'Google Font', 'powen-lite' ),
		'description' => __( 'Set your website default font', 'powen-lite' ),
		'type'     => 'select',
		'section'  =>  'powen_fonts_section',
		'settings' =>  'powen_mod[pro_fonts]',
		'choices' =>  powen_library_get_font_choices(),
	) ) );

	//Modify Text

	//Theme Author Url

	$wp_customize->add_setting('powen_mod[theme_author_url]', array(
		'default' => esc_url('http://supernovathemes.com'),
		'sanitize_callback' => 'sanitize_text_field',
		'capability' => 'edit_theme_options',
	));

	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'powen_mod[theme_author_url]', array(
		'label' => __("Author's URL", 'powen-lite'),
		'section' => 'powen_modify_text_section',
		'settings' => 'powen_mod[theme_author_url]',
	)));

	//Site title footer

	$wp_customize->add_setting('powen_mod[site_title_footer]', array(
		'default' => 'Powen',
		'sanitize_callback' => 'sanitize_text_field',
		'capability' => 'edit_theme_options',
	));

	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'powen_mod[site_title_footer]', array(
		'label' => __("Site Title", 'powen-lite'),
		'section' => 'powen_modify_text_section',
		'settings' => 'powen_mod[site_title_footer]',
	)));

	//After site title footer

	$wp_customize->add_setting('powen_mod[after_site_title_footer]', array(
		'default' => __('by', 'powen-lite'),
		'sanitize_callback' => 'sanitize_text_field',
		'capability' => 'edit_theme_options',
	));

	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'powen_mod[after_site_title_footer]', array(
		'label' => __("After Site Title", 'powen-lite'),
		'section' => 'powen_modify_text_section',
		'settings' => 'powen_mod[after_site_title_footer]',
	)));

}

add_action( 'powen_customize_ends', 'powen_customizer_pro_options' );


/*==============================
          Ads New CSS
===============================*/


function powen_pro_custom_css(){
	Powen_Customizer_Front::generate_css( '.powen-wrapper, .site-content', 'max-width', 'flexible_layout', '', 'px', '1150' );
	Powen_Customizer_Front::generate_css( 'body, .mm-menu, input[type=search], input[type="submit"], input[type="text"], input[type="email"], input[type="url"], input[type="password"], textarea', 'font-family', apply_filters( 'powen-lite-body-font-key', 'theme_font' ), '"', '"', 'Open Sans' );
	Powen_Customizer_Front::generate_css('#mm-powen-pro-nav', 'background-color', 'pro_nav_background_color', '');
	Powen_Customizer_Front::generate_css('#mm-powen-pro-nav', 'color', 'pro_nav_color', '');
	Powen_Customizer_Front::generate_css( '.powen-pro-nav', 'font-size', 'nav_font_size', '', 'rem', '0.928', true, '(min-width:900px)' );
	Powen_Customizer_Front::generate_css( '.powen-footer-nav', 'font-size', 'nav_font_size', '', 'rem', '0.928', true, '(min-width:900px)' );
}
add_action( 'powen_lite_custom_css_end' , 'powen_pro_custom_css' );


function powen_add_new_body_font(){
	return 'pro_fonts';
}
add_filter( 'powen-lite-body-font-key', 'powen_add_new_body_font' );

function powen_add_menu_colors( $key ){

	$key[] = array(
		'slug'    =>'powen_mod[pro_nav_background_color]',
		'default' => '#222222',
		'label'   => __( 'Pro Menu Background Color', 'powen-lite' ),
	);
	$key[] = array(
		'slug'    =>'powen_mod[pro_nav_color]',
		'default' => '#cccccc',
		'label'   => __( 'Pro Menu Color', 'powen-lite' ),
	);

	return $key;
}
add_filter( 'powen_theme_colors_array', 'powen_add_menu_colors' );