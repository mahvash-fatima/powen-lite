<?php
/**
 * Easy Digital Downloads Theme Updater
 *
 * @package powen
 */

// Includes the files needed for the theme updater
if ( !class_exists( 'EDD_Theme_Updater_Admin' ) ) {
	include( dirname( __FILE__ ) . '/theme-updater-admin.php' );
}

// Loads the updater classes
$updater = new EDD_Theme_Updater_Admin(

	// Config settings
	$config = array(
		'remote_api_url' => 'http://supernovathemes.com/', // Site where EDD is hosted
		'item_name'      => 'Powen Pro Developer License',
		// 'item_name'      => 'Powen Pro Personal Lifetime License',
		// 'item_name'      => 'Powen Pro Personal License',
		'theme_slug'     => 'powen-lite', // Theme slug
		'version'        => '1.3.0', // The current version of this theme
		'author'         => 'Mahvash Fatima', // The author of this theme
		'download_id'    => '', // Optional, used for generating a license renewal link
		'renew_url'      => '' // Optional, allows for a custom license renewal link
	),

	// Strings
	$strings = array(
		'theme-license'             => __( 'Theme License', 'powen-lite' ),
		'enter-key'                 => __( 'Enter your theme license key.', 'powen-lite' ),
		'license-key'               => __( 'License Key', 'powen-lite' ),
		'license-action'            => __( 'License Action', 'powen-lite' ),
		'deactivate-license'        => __( 'Deactivate License', 'powen-lite' ),
		'activate-license'          => __( 'Activate License', 'powen-lite' ),
		'status-unknown'            => __( 'License status is unknown.', 'powen-lite' ),
		'renew'                     => __( 'Renew?', 'powen-lite' ),
		'unlimited'                 => __( 'unlimited', 'powen-lite' ),
		'license-key-is-active'     => __( 'License key is active.', 'powen-lite' ),
		'expires%s'                 => __( 'Expires %s.', 'powen-lite' ),
		'%1$s/%2$-sites'            => __( 'You have %1$s / %2$s sites activated.', 'powen-lite' ),
		'license-key-expired-%s'    => __( 'License key expired %s.', 'powen-lite' ),
		'license-key-expired'       => __( 'License key has expired.', 'powen-lite' ),
		'license-keys-do-not-match' => __( 'License keys do not match.', 'powen-lite' ),
		'license-is-inactive'       => __( 'License is inactive.', 'powen-lite' ),
		'license-key-is-disabled'   => __( 'License key is disabled.', 'powen-lite' ),
		'site-is-inactive'          => __( 'Site is inactive.', 'powen-lite' ),
		'license-status-unknown'    => __( 'License status is unknown.', 'powen-lite' ),
		'update-notice'             => __( "Updating this theme will lose any customizations you have made. 'Cancel' to stop, 'OK' to update.", 'powen-lite' ),
		'update-available'          => __('<strong>%1$s %2$s</strong> is available. <a href="%3$s" class="thickbox" title="%4s">Check out what\'s new</a> or <a href="%5$s"%6$s>update now</a>.', 'powen-lite' )
	)

);
