<?php


/*==============================
          Definitions
===============================*/

if( ! defined( 'POWEN_PRO_DIR' )) define( 'POWEN_PRO_DIR'	, POWEN_DR . '/pro' );
if( ! defined( 'POWEN_PRO_URI' )) define( 'POWEN_PRO_URI' , POWEN_URI . '/pro' );
if( ! defined( 'POWEN_PRO_IMAGES' )) define( 'POWEN_PRO_IMAGES'	, POWEN_URI .'/img/' );


/*==============================
          File Includes
===============================*/

require_once POWEN_PRO_DIR . '/updater/theme-updater.php';
require_once POWEN_PRO_DIR . '/custom-functions.php';
require_once POWEN_PRO_DIR . '/hooks.php';
require_once POWEN_PRO_DIR . '/customizer/fonts.php';
require_once POWEN_PRO_DIR . '/customizer/customizer-hooks.php';
require_once POWEN_PRO_DIR . '/customizer/customizer-backend.php';
require_once POWEN_PRO_DIR . '/font-icon.php';


add_action( 'wp_enqueue_scripts' , 'powen_pro_enquque_scripts' );
function powen_pro_enquque_scripts()
{
	$body_font_url = powen_library_get_google_font_uri( 'pro_fonts', 'Open Sans' );

	if ( $body_font_url ) wp_enqueue_style( 'powen_pro_fonts', $body_font_url );


	wp_enqueue_style( 'powen_pro_styles', POWEN_PRO_URI . '/pro.css' , array( 'powen-style' ) , POWEN_VERSION );
	wp_enqueue_script( 'powen_pro_scripts', POWEN_PRO_URI . '/js/pro.js' , array( 'jquery' ) , POWEN_VERSION, true );
	wp_localize_script( 'powen_pro_scripts' , 'powenProVars', array(
			'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
			'loading'      => __( 'Loading...' , 'powen-lite' ),
			'loadMore'     => __( 'Load More' , 'powen-lite' ),
			'showLoadMore' => true,
			'loadonScroll' => true
		));
}

/*==============================
          Powen Pro Nav
===============================*/

add_filter( 'powen_add_navigation', 'powen_pro_menu' );
function powen_pro_menu( $menu_array )
{
	$menu_array['powen-pro-nav'] = __( 'Pro Menu' , 'powen-lite' );
	$menu_array['powen-footer-nav'] = __( 'Footer Menu' , 'powen-lite' );

	return $menu_array;
}

