(function($){

	"use strict";

	window.PowenPro = {

		count                 : 0,
		responseRecieved      : false,
		scrollLoadRequestSent : false,
		postsAvailable        : true,
		$ajaxPostContainer    : $('.powen-infinite-posts-container'),
		vars                  : powenProVars !== 'undefined' ? powenProVars : {},
		$loadMoreButton       : $('#powen-load-more'),

		init: function(){
			this.events();
			this.proMenu();
		},

		events : function(){
			this.$loadMoreButton.on( 'click', this.loadMore );
			$(window).on( 'scroll' , this.loadOnScroll );
		},

		loadMore : function(e){

			if( e ) e.preventDefault();

			var _this = PowenPro;
			var $data = false;

			if( _this.postsAvailable === false ) return;
			if( ! _this.vars.showLoadMore ) return;
			if( ! this.$ajaxPostContainer.length ) return;

			_this.responseRecieved = false;

			_this.count++;

			_this.$loadMoreButton.text(_this.vars.loading).prop( 'disabled', true );

			$.ajax({
				url: _this.vars.ajaxUrl,
				type: 'POST',
				dataType: 'html',
				data: {
					action : 'powen_load_more',
					count: _this.count
				},
			})
			.done(function( resp ) {
				$data = $( resp );
				_this.$ajaxPostContainer.append( $data );

				$data.addClass('animated fadeInUp');

				//When there are no posts avaiable.
				if( ! resp ) {
					_this.$loadMoreButton.fadeOut();
					_this.postsAvailable = false;
				}

			})
			.fail(function(error) {
				console.log("error", error);
			})
			.always(function() {
				_this.$loadMoreButton.text(_this.vars.loadMore).prop( 'disabled', false );
				_this.responseRecieved = true;
			});

		},

		loadOnScroll : function( e ){

			var _this = PowenPro;

			if( ! _this.vars.loadonScroll ) return;

			if( _this.responseRecieved === true ) _this.scrollLoadRequestSent = false;

			if( _this.scrollLoadRequestSent === true ) return;

			var $ajaxRefContainer  = $('.powen-infinite-posts-container');

			if( ! $ajaxRefContainer.length ) return;

			var targetElTopOffset = $ajaxRefContainer.offset().top + $ajaxRefContainer.outerHeight() - 500;
			var documentScrollTop = $(document).scrollTop();

			if( documentScrollTop > targetElTopOffset ){
				_this.scrollLoadRequestSent = true;
				_this.loadMore( false );
			}

		},

		//Pro Menu
		proMenu: function(){
			var $proNavigation = $('#powen-pro-nav');
			$proNavigation.mmenu({}, {clone: true}).on( 'opened.mm', function() {
				$proNavigation.trigger("open.mm");
			});

			var proMenuAnimate  = $("#powen-pro-nav li ul");

			proMenuAnimate.addClass('fadeInUp');

			$("#mm-powen-pro-nav").removeClass('powen-pro-nav');

		},
	};

	$(document).ready(function(){
		window.PowenPro.init();
	});

})(jQuery);