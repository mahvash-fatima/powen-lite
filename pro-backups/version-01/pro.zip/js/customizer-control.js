/**
 *  Contains custom scripts
 */

(function( $, window , undefined ){

    "use strict";

    $(document).ready(function(){

   	//Pro Icon

	var loadMore        = $("#accordion-section-powen_load_more_section>h3"),
	flexibleLayout      = $("#accordion-section-powen_flexible_layout_section>h3"),
	infiniteScrolling   = $("#accordion-section-powen_infinite_scrolling_section>h3"),
	pagination          = $("#accordion-section-powen_pagination_section>h3"),
	addSpots            = $("#accordion-panel-powen_add_spots_pannel>h3"),
	typography          = $("#accordion-section-powen_fonts_section>h3"),
	menu                = $("#accordion-panel-nav_menus>h3"),
	contentPanel        = $("#accordion-panel-powen_content_pannel>h3"),
	menuHeaderSelect    = $(".customize-control-nav_menu_locations-powen-pro-nav"),
	menuFooterSelect    = $(".current-menu-location-name-powen-footer-nav"),
	menuTitleTextbox    = $("#customize-control-powen_mod-menu_three_title_textbox .customize-control-title"),
	menuFooterLocation  = $(".current-menu-location-name-powen-pro-footer-menu"),
	menuHeaderLocation  = $(".current-menu-location-name-powen-pro-nav"),
	footerMenu          = $("#customize-control-nav_menu_locations-powen-footer-nav"),
	switchOffFooterMenu = $("#customize-control-powen_mod-hide_footer_nav"),
	proMenuTitle        = $("#customize-control-powen_mod-pro_mobile_nav_title_textbox .customize-control-title"),
	proMenuHide         = $("#customize-control-powen_mod-hide_pro_mobile_nav label"),
	modifyText          = $("#accordion-section-powen_modify_text_section>h3"),
	authorUrl           = $("#customize-control-powen_mod-theme_author_url"),
	siteTitle           = $("#customize-control-powen_mod-site_title_footer"),
	afterSiteTitleFooter= $("#customize-control-powen_mod-after_site_title_footer"),
	fontIcon            = $("#accordion-panel-powen_font_icon_panel>h3");

	loadMore.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='powen-pro-icon'>");
	flexibleLayout.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='powen-pro-icon'>");
	infiniteScrolling.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='powen-pro-icon'>");
	pagination.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='powen-pro-icon'>");
	addSpots.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='powen-pro-icon'>");
	typography.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='powen-pro-icon'>");
	menu.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='powen-pro-icon'>");
	contentPanel.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='powen-pro-icon'>");
	menuHeaderSelect.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='powen-pro-icon'>");
	menuFooterSelect.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='powen-pro-icon'>");
	menuTitleTextbox.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='powen-pro-icon'>");
	menuFooterLocation.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='powen-pro-icon'>");
	menuHeaderLocation.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='powen-pro-icon'>");
	footerMenu.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='powen-footer-menu-icon'>");
	switchOffFooterMenu.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='powen-switch-off-footer-menu-icon'>");
	proMenuTitle.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='pro-menu-title'>");
	proMenuHide.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='pro-menu-hide'>");
	modifyText.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='pro-menu-hide'>");
	authorUrl.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='pro-menu-title'>");
	siteTitle.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='pro-menu-hide'>");
	afterSiteTitleFooter.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='pro-menu-hide'>");
	fontIcon.append("<img src='" + powen_pro_images + "/powen-pro-icon.png' class='pro-menu-hide'>");

    });

})( jQuery , window, undefined );