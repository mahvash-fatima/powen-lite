<?php

/*==============================
      Infinite Scroll Ajax
===============================*/

function powen_get_next_posts( $offset, $posts_per_page ) {
	$args = array(
		'posts_per_page'      => $posts_per_page,
		'ignore_sticky_posts' => true,
		'post_status'         => 'publish',
		'orderby'             => 'date',
		'order'               => 'DESC',
		'offset'              => $offset,
	);

	$query = new WP_Query( $args );

	if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post();

		get_template_part( 'content' );

	endwhile; endif;
	wp_reset_postdata();
}

add_action( 'wp_ajax_powen_load_more', 'powen_load_more' );

add_action( 'wp_ajax_nopriv_powen_load_more', 'powen_load_more' );

function powen_load_more() {
	$posts_per_page = get_option( 'posts_per_page' );

	$count = isset( $_POST['count'] ) ? $_POST['count'] : false;

	$offset = $posts_per_page * $count + 1;

	powen_get_next_posts( $offset, $posts_per_page );

	die();
}

function powen_display_pagination() {
	if ( powen_mod( 'pagination' ) ) {
		echo "<style>";
		echo ".powen-pagination { display: none }";
		echo "</style>";
	}
}

add_action( 'wp_head', 'powen_display_pagination' );