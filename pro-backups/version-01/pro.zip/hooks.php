<?php

/*==============================
			Ad Spots
===============================*/

function powen_header_primary() {
	if ( powen_mod( 'header_primary' ) ) {
		echo powen_mod( 'header_primary' );
	}
}

add_action( 'powen_header_primary', 'powen_header_primary' );

function powen_before_site_branding() {
	if ( powen_mod( 'before_site_branding' ) ) {
		echo powen_mod( 'before_site_branding' );
	}
}

add_action( 'powen_before_site_branding', 'powen_before_site_branding' );

function powen_after_site_branding() {
	if ( powen_mod( 'after_site_branding' ) ) {
		echo powen_mod( 'after_site_branding' );
	}
}

add_action( 'powen_after_site_branding', 'powen_after_site_branding' );

function powen_after_first_home_post() {
	if ( powen_mod( 'after_first_home_post' ) ) {
		echo powen_mod( 'after_first_home_post' );
	}
}

add_action( 'powen_after_first_home_post', 'powen_after_first_home_post' );

function powen_above_footer() {
	if ( powen_mod( 'above_footer' ) ) {
		echo powen_mod( 'above_footer' );
	}
}

add_action( 'powen_above_footer', 'powen_above_footer' );

function powen_footer_widgets() {
	if ( powen_mod( 'footer_widgets' ) ) {
		echo powen_mod( 'footer_widgets' );
	}
}

add_action( 'powen-footer-widgets', 'powen_footer_widgets' );

function powen_footer_site_info_begins() {
	if ( powen_mod( 'footer_site_info_begins' ) ) {
		echo powen_mod( 'footer_site_info_begins' );
	}
}

add_action( 'powen_footer_site_info_begins', 'powen_footer_site_info_begins' );

function powen_footer_site_info_ends() {
	if ( powen_mod( 'footer_site_info_ends' ) ) {
		echo powen_mod( 'footer_site_info_ends' );
	}
}

add_action( 'powen_footer_site_info_ends', 'powen_footer_site_info_ends' );

function powen_before_content() {
	if ( powen_mod( 'before_content' ) ) {
		echo powen_mod( 'before_content' );
	}
}

add_action( 'powen_before_content', 'powen_before_content' );


/*==============================
          Powen Pro Menu
===============================*/

function powen_hook_pro_menu() {
	if ( powen_mod( 'hide_pro_mobile_nav' ) == '' ) {
		echo "<nav id='powen-pro-nav' class='powen-pro-nav'>";
		wp_nav_menu( array(
			'theme_location' => 'powen-pro-nav',
			'menu_id'        => 'powen-pro-nav',
			'depth'          => apply_filters( 'powen-pro-nav-depth', 3 ),
		) );
		echo "</nav>";
	}
}

add_action( 'powen_after_site_branding', 'powen_hook_pro_menu' );

function powen_hook_pro_mobile_menu() {
	if ( powen_mod( 'hide_pro_mobile_nav' ) == '' ) {
		echo "<nav class='powen-pro-mobile-nav'><a href='#powen-pro-nav' class='powen-pro-mobile-navigation'><i class='mm'></i>" . esc_textarea( powen_mod( 'pro_mobile_nav_title_textbox' ), 'powen-lite' ) . "</a></nav>";
	}
}

add_action( 'powen_before_mobile_nav', 'powen_hook_pro_mobile_menu' );

function powen_hook_footer_pro_menu() {
	if ( powen_mod( 'hide_footer_nav' ) == '' ) {
		echo "<nav class='powen-footer-nav'>";
		wp_nav_menu( array(
			'theme_location' => 'powen-footer-nav',
			'menu_id'        => 'powen-footer-nav',
			'depth'          => apply_filters( 'powen-footer-nav', 1 ),
		) );
		echo "</nav>";
	}
}

add_action( 'powen_footer_site_info_begins', 'powen_hook_footer_pro_menu' );

/*==============================
       Infinite Scroll Support
===============================*/

function powen_infinite_scroll_box() {
	if ( ! is_home() || ! is_front_page() ) {
		return;
	}

	$post_per_page = get_option( 'posts_per_page' );

	if ( powen_mod( 'stop_infinite_ajax_scrolling' ) == 0 ) {

		echo '<div class="powen-infinite-scroll-container">
				<div class="powen-infinite-posts-container">
					</div>';
		if ( powen_mod( 'load_more' ) == 0 ) {
			echo '<div class="powen-infinite-loader-container">
					<button data-posts-per-page="' . $post_per_page . '" id="powen-load-more" class="powen-load-more">' . __( 'Load More', 'powen-lite' ) . '</button>
				</div>';
		}
		echo '</div>';

	}
}

add_action( 'powen_before_pagination', 'powen_infinite_scroll_box' );

function powen_pro_footer_site_info() {
	$footerUrl = esc_url( 'http://supernovathemes.com' );
	$theme_author_url = powen_mod('theme_author_url', 'http://supernovathemes.com');
	$site_title_footer = powen_mod( 'site_title_footer', 'Powen' );
	$after_site_title_footer = powen_mod( 'after_site_title_footer', __( 'by', 'powen-lite' ) );
	$theme_author = powen_mod( 'theme_author', 'Supernova Themes' );
	?>

	<?php if ( $theme_author || $site_title_footer || $after_site_title_footer ) { ?>
	<span class="sep"><?php echo apply_filters( 'powen_footer_site_info_pipe',  ' |'  ); ?></span>
	<?php } ?>

	<span class="powen-site-info">
		<span class="powen-site-identity"><?php echo $site_title_footer;  ?> <?php echo $after_site_title_footer; ?></span>
			<a href="<?php echo $theme_author_url; ?>" class="powen-site" rel="designer">
				<?php echo $theme_author; ?>
			</a>
	</span>
	<?php
}
